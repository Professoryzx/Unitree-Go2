# CE-STPM 论文相关材料

对应论文：**Causally Inspired Feature Calibration for Out-of-Distribution State-Transition Prediction in Quadrupedal Locomotion**。

这是根据作者提供的论文和 Go2 项目压缩包整理的部分材料，当前仍为本地准备版，尚未确认目标仓库并上传。它能够检查论文表格、查看项目坐标文件及其来源，不能作为整篇论文实验已完整复现的证明。

## 已整理的内容

- 论文8张表的CSV和JSON，包含171条数值结果；从Word独立核对表格单元格。
- 项目自带的87个TXT原文件及校验值：80个坐标导出文件、7个环境说明文件，共980条坐标记录，包含4条BLOCK标记。
- 坐标文件转换工具、文件/序列清单、数据字典和离线检查脚本。
- 稿件中已报告的实验参数与分布说明，记录为文档配置，不冒充可运行的训练配置。
- 汇总数值改善率复算脚本、出处审计、数据获取声明草稿及文件完整性检查。

文件中的B、G、Y等标记是编辑器颜色，尚无证据可将它们当作CE-STPM、对照模型或真值。原目录里的ood、FA消融等名称只保留其原始分组含义，不能直接转成论文的ID/OOD-G/OOD-P划分。87个TXT也不是论文所述的150条实机片段。

## 使用

在本目录运行，Python 3.9及以上即可，不需安装仿真器：

```bash
python3 scripts/verify_checksums.py
python3 scripts/check_waypoints.py
python3 scripts/check_reported_results.py
```

详见[数据清单](docs/DATA_INVENTORY.md)、[复现实验需要的材料](docs/REPRODUCIBILITY.md)及[原项目审计](docs/PROJECT_AUDIT.md)。

## 公开范围

压缩包中没有找到CE-STPM/T-BAM/D-FAM预测网络实现、训练划分、完整状态观测、风险标签或逐样本预测结果。原项目包含PPO步态控制器和轨迹工具，但它们不能替代论文预测模型。完整原项目已保留在本地；当前材料包不包含原项目源码树、权重、USD、Pickle和整篇稿件。

原项目和TXT文件没有提供统一许可证；本次整理不为它们擅自添加MIT或CC许可证。数据目录标注其出处和当前权利状态。实际公开后，应按真实发布范围填写论文数据获取声明，不能直接写成全部数据和模型代码均已开放。
