# Rights and licence status

No repository-wide software or data licence has been assigned in this preparation step.

| Material | Observed status | Treatment in this package |
| --- | --- | --- |
| Manuscript table values and author metadata | Provided by the author; no separate dataset licence supplied | Transcribed with provenance; licence selection remains an author/institution decision |
| Project waypoint/environment text exports | Present in the author-supplied archive; no explicit data licence supplied | Original bytes retained and identified; no reuse licence invented |
| New curation tools and documentation | Written during repository preparation | Kept separate from the source simulator; no claim that their terms cover third-party material |
| Original simulation project | No LICENSE/NOTICE in the supplied archive; mixed third-party attribution and SPDX headers | Full source tree, weights, scenes and Pickle files excluded from this deposit |

Public availability and a licence granting reuse are different facts. This file records the current evidence and does not constitute an open licence, a new restriction, or a claim that authorisation is unavailable. A standard licence can be added to author-controlled material once its scope is specified; third-party files must retain applicable notices and terms.

See `docs/PROJECT_AUDIT.md` for the upstream links and file-level findings. The public/private visibility of a source repository must not be treated as a licence.
