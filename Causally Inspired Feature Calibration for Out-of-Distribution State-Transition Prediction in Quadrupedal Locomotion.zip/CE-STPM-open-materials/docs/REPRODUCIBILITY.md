# What is needed to rerun the study

The included curation tools are runnable independently of the simulator. The supplied project is a platform snapshot, and this deposit is not a complete CE-STPM implementation. A complete experiment release would need the following author-held material.

| Evidence | Required fields/files | Supports |
| --- | --- | --- |
| Simulation raw sequences | Stable sequence ID; frames or timestamps; acquisition interval; world-frame positions; historical and future commands; aligned 48-component proprioception; elevation observations; risk-label definitions and values | Training and prediction-window construction |
| Terrain/contact metadata | Terrain category, friction/contact settings, geometry configuration, acquisition seeds, prototype construction inputs and exclusions | ID/OOD-G/OOD-P, association test and friction sweep |
| Split manifest | Explicit training/validation/test sequence or window IDs, collection rounds, seeds and overlap policy | Distribution protocol and leakage checks |
| Predictor implementation | CE-STPM network, T-BAM/D-FAM, losses, training command, evaluation command, hyperparameters, dependency versions, trained predictor weights | Model execution and comparison with shared-backbone variants |
| Prediction output | For every method/split/sequence: true and predicted planar positions at all ten forecast steps, risk labels and scores, classification threshold and evaluation aggregation | Independent ADE/FDE, precision, recall and F1 computation |
| Physical-robot snippets | The 150 snippet IDs, scene groups, timestamps, aligned FAST-LIO positions, observations, planned commands, risk labels and offline terrain-prior lookup inputs | Table 8 and field plots |
| Figure provenance | Sample/panel IDs, arrays, coordinate transforms, overlay definitions and plotting scripts | Qualitative figures and source-data inspection |

The paper reports a history of five samples and a prediction horizon of ten steps. It reports raw simulation acquisition at 40 Hz. These are documented settings, not evidence that the coloured waypoint exports contain those aligned signals. The auxiliary risk threshold of 0.6 is a training-loss setting; it must not be assumed to be the risk-classification threshold without the actual evaluation protocol.

For standard displacement metrics, compute each window's planar Euclidean error at each forecast step; ADE is its average over steps and FDE its final-step error. To reproduce Table 4, preserve per-window values and the manuscript's aggregation and sample-standard-deviation convention. Risk metrics need the actual labels/scores and denominator rules; rounded table summaries alone cannot reconstruct those counts.

## Local preparation validation

- Source text exports are preserved byte for byte and identified by SHA256.
- Normalized coordinate values and source-row references can be checked against original exports.
- Eight manuscript tables are cross-checked against the corresponding Word tables.
- `check_reported_results.py` checks arithmetic based on reported aggregate values only.
- Original simulator Python files received a static syntax audit; the GPU simulator and robot experiments were not run on this Mac during preparation.

## Publication record

After publishing to the chosen repository, record the actual repository URL and immutable commit or release identifier in `metadata.json` and `CITATION.cff`. A dataset DOI can be added if an archival repository actually issues one. Do not invent an identifier or describe an unuploaded draft as publicly accessible. The manuscript statement should identify the exact released files and remaining omissions.
