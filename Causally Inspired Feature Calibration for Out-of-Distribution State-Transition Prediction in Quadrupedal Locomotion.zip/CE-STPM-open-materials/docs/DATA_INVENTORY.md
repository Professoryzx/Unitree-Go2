# Data inventory and evidence mapping

This inventory describes material actually found in the author-supplied ZIPs. A missing item is not asserted to be unavailable elsewhere; it was not provided for this preparation.

| Material | Included here | Relationship to manuscript |
| --- | --- | --- |
| Tables 1–3: notation, configuration and distribution protocol | CSV and JSON transcription | Documents the manuscript settings; does not supply actual split sample IDs or executable model parameters |
| Table 4: simulated displacement errors | Reported means and sample standard deviations | Arithmetic comparisons can be recomputed; sample errors and statistics cannot be independently recalculated |
| Table 5: simulated precision, recall and F1 | Reported summary values | No per-step labels, scores or confusion matrices were supplied |
| Table 6: preserved/broken association test | Reported FDE and relative increases | No original paired runs, collection seeds or split manifests were supplied |
| Table 7: friction sweep | Reported FDE at three coefficients | No prediction/ground-truth sequences were supplied |
| Table 8: physical-robot comparison | Reported scene-group summaries | The 150 physical-robot snippets and aligned sensor observations were not supplied |
| Figures 4 and 7 | Values represented in Tables 4, 5 and 8 | Table-based numerical summaries are deposited; original plotting code is not supplied |
| Figures 1–3, 5 and 6 | Not redistributed | Diagrams and qualitative figure images remain in the author's manuscript submission package; their underlying arrays/annotations are absent here |
| Project waypoint TXT | 87 text exports and normalized CSV | Auxiliary project material; no verified correspondence to manuscript methods/splits or plotted predictions |
| Heightmap PNG, controller checkpoints and simulator USD/Pickle | Not redistributed | Rendered images, low-level control weights and simulator assets; not established as CE-STPM training/evaluation data |
| CE-STPM/T-BAM/D-FAM source and predictor weights | Not found in supplied ZIP | Required for rerunning the proposed predictor |

The waypoint export has relative coordinates and colour identifiers, but lacks aligned velocities, time intervals, proprioception, elevation arrays, future action windows and risk targets. In particular, the colours do not establish model identity or risk class.

The package records missing information explicitly, preserves source values, and supplies checksums. No synthetic observations, substituted predictions, guessed model labels or reconstructed raw experiment records have been inserted.

See each dataset README for variables, units, schema, transformation methods and file provenance. `LICENSE_STATUS.md` records the currently unspecified licence scope.
