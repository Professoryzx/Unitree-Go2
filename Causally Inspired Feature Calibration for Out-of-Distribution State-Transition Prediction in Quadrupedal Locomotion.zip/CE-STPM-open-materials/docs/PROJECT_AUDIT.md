# Audit of the supplied simulation project

Audit date: 1 October 2026. Source inspected: the supplied `Unitree_go2_ros2_isaacsim-main.zip`, extracted locally without modifying its contents. File and line references below refer to that extracted snapshot, which is retained in the local archive rather than distributed in this repository.

## Scope of this release

This repository contains manuscript-level summary tables, newly prepared documentation and inspection tools, and waypoint-coordinate files traced to the supplied archive. The archive establishes the provenance of those coordinate files; it does **not** establish their mapping to the manuscript's training, validation, test or out-of-distribution splits, trial identifiers, model variants, or reported metrics. Directory names such as `ood` and `FA消融` are retained source labels, not independently verified experimental assignments.

The supplied project contains a Go2 simulation platform, low-level PPO control, trajectory recording and replay mechanisms, and coordinate editing and visualization utilities. The inspection did not identify the CE-STPM, T-BAM or D-FAM training and prediction implementations described in the manuscript. Consequently, this release should be cited as supporting materials with the limitations stated here. It does not establish reproduction of all manuscript results.

The full supplied source tree, controller checkpoints, USD scenes and Pickle files remain in the local archive. They are not redistributed with this public package. Missing recordings, model code, checkpoints, dataset splits and trial-level outputs have not been reconstructed or invented.

## What was checked

- All 47 Python source files in the supplied archive were parsed using Python's `ast.parse`; no syntax errors were detected.
- Text searches and source inspection checked model identifiers, imports, local paths, recording formats, policy loading and provenance notices.
- The inspection did not import the simulation modules, launch Isaac Sim, run training or inference, load checkpoints, deserialize Pickle files, or validate the paper's experimental results.

Syntax validation alone does not establish that the simulator or experiments run successfully.

## Findings from the archived snapshot

| Finding | Source evidence | Implication |
| --- | --- | --- |
| Model implementation was not identified | Searches across the Python sources found no CE-STPM, T-BAM or D-FAM implementations. | The supplied snapshot cannot establish the manuscript's model-training or prediction pipeline. |
| A script uses the label `predicted_path` for a constant-velocity calculation | `exp2.py:51–65` updates `x` and `y` with `vx * dt` and `vy * dt`; `exp2.py:206–240` reads command sequences and invokes that calculation. | This path calculation should not be described as CE-STPM prediction. |
| RL entry points train control policies | `run_rl.py:107–178` constructs an RSL-RL `OnPolicyRunner` for PPO; `go2/__init__.py:14–33` registers Go2 environments. | These files are control-policy training infrastructure, not evidence of state-transition-predictor training. |
| Supplied checkpoints are used by low-level controllers | `go2/go2_ctrl.py:158–185` loads policies for Flat/Rough Unitree velocity environments; `go2/go2_ctrl_cfg.py:1–77` specifies ActorCritic/PPO configurations. | The files `flat_model_6800.pt` and `rough_model_7850.pt` should not be relabeled as CE-STPM model weights. Their binary contents were not loaded. |
| One controller configuration refers to a nonexistent checkpoint name | `go2_rl/go2_ctrl_cfg.py:76` requests `model_7850.pt`; the archive instead includes `rough_model_7850.pt`. | This configuration needs correction before that controller is run. |
| A trajectory follower uses geometric tracking and smoothing | `run_trajectory_following.py:137–165` introduces pure pursuit, lateral-error handling, low-pass filters and rate limiters. | This is not evidence of the manuscript's learned predictor or an MPPI implementation. |
| Required navigation extensions are absent from the archive | `.gitmodules:1–3` declares `nav-suite`; no submodule checkout is included. `go2/go2_env.py:24` imports `nav_suite`, and `env/cfg/terrain_cfg.py:13` imports `nav_tasks`. | Both extensions are required by the inspected import chain; installing the supplied ZIP alone is insufficient. |
| Local absolute paths prevent portable execution | `env/cfg/terrain_cfg.py:15` and `go2_rl/go2_env.py:29` contain user-specific absolute paths; `go2/go2_env.py:123–129` resolves the default USD scene using the former path. | Environment paths need configuration on a new machine. |
| Recording mechanisms exist, but recording files are missing | `go2/teleop_recorder.py:20–50,54–113` defines JSON command/pose recording. `experiment1.py:43`, `exp2.py:99`, `replay_recording.py:34,39`, `replay_recording2.py:38,43`, and `run_trajectory_following.py:18` refer to JSON files under `recordings`. No `recordings` directory is present in the supplied snapshot. | The code demonstrates a recording format; it does not supply the command/state sequences referenced by these entry points. |
| Coordinate text files omit temporal and state information | `PL.py:852–887` writes `COLOR rel_x rel_y rel_z color_r color_g color_b` with a world-frame base reference. | Coordinates and visualization colors alone do not establish a time-indexed state-transition dataset or the meaning of model assignments. |
| Height-map PNGs are rendered visualizations | `height_map.py:435–513` reads ray-hit heights, normalizes them and renders PNG images with a color bar. It does not save the corresponding raw height array in that routine. | The PNGs should not be described as numerical height-grid data. |
| The original README retains conflict markers | `README.md:1–2` contains two `<<<<<<< HEAD` lines. No such markers were found in the Python sources. | The original README needs editorial cleanup if the full project is separately released. |

## Environment records and unresolved reproducibility details

The archived README records Ubuntu 22.04, Python 3.10, ROS2 Humble, Isaac Sim 4.5.0 and IsaacLab 2.1.0 (`README.md:4–10,28–32`). No dependency lock file or exact runtime-environment export was supplied. The value `2.3.1` in `run_rl.py:59–61` is a minimum-version check for distributed RSL-RL training, not a verified installed version.

The [official Isaac Navigation Suite instructions](https://github.com/leggedrobotics/nav-suite#installation) describe separate `nav_suite` and `nav_tasks` extensions, record testing with IsaacLab 2.1.1, and mention Git LFS assets. These upstream instructions are useful dependency references; they do not establish the version used to produce the supplied archive or the paper's results.

The following evidence is still needed for complete result reproduction: the predictor training/inference implementation; synchronized state, command and terrain data; exact split and normalization definitions; trial and seed records; predictor checkpoints; baseline and ablation configurations; and metric-generation outputs linking trials to manuscript tables and figures. None of those missing artifacts is substituted by the summary tables or coordinate files in this release.

## Provenance and license boundaries

The archived README points to [Zhefan-Xu/isaac-go2-ros2](https://github.com/Zhefan-Xu/isaac-go2-ros2) at line 42 and acknowledges [go2_omniverse](https://github.com/abizovnuralem/go2_omniverse) at line 114. These references identify acknowledged upstream projects; the supplied ZIP does not establish its exact upstream Git revision.

No `LICENSE`, `NOTICE` or `COPYRIGHT` file was found in the supplied archive. The inspected upstream `isaac-go2-ros2` default branch did not expose a root license file, and its root `LICENSE` raw URL returned 404 at the time of inspection. A repository-wide redistribution license therefore remains unverified for that source tree. This package does not assign MIT or another replacement license to the archived project.

The [go2_omniverse license](https://github.com/abizovnuralem/go2_omniverse/blob/master/LICENSE) is BSD-2-Clause. The [Isaac Navigation Suite license](https://github.com/leggedrobotics/nav-suite/blob/main/LICENSE) is Apache-2.0, and its [asset/dependency license directory](https://github.com/leggedrobotics/nav-suite/tree/main/docs/licenses) contains separate notices. Several archived IsaacLab/ETH source files also retain BSD-3-Clause SPDX identifiers and copyright headers, for example `go2/__init__.py:1–4`, `run_rl.py:1–4`, and `env/cfg/terrain_cfg.py:1–5`. These distinct notices should remain attached to their respective materials; they do not resolve the license of every file in the supplied archive.

## 中文说明

本次只做了静态检查，没有运行 Isaac Sim、训练或模型推理，也没有加载权重或 Pickle 文件。原项目具备轨迹录制机制，但压缩包没有 `recordings` 目录及脚本所引用的 JSON 录制数据；现有 `.txt` 主要记录坐标与显示颜色，无法据此还原完整的状态、指令和时间序列。

公开材料中的汇总表来自稿件，坐标文件来自用户提供的项目包。坐标文件与论文训练/验证/OOD 划分、模型名称及指标的对应关系尚未证实，不能称为已核验的全部实验原始数据。本次未找到 CE-STPM、T-BAM、D-FAM 的完整实现，也没有补造缺失代码或数据。完整源码、控制器权重、USD 场景和 Pickle 文件保留在本地归档；未擅自为上游项目添加 MIT 许可证。
