# Data Availability wording

The current manuscript states: “The data and implementation code supporting this study will be made publicly available upon acceptance.” The manuscript has not been edited during repository preparation.

## Current status

This package was prepared locally on 1 October 2026. The author has requested a GitHub deposit, but the destination URL and successful upload are not yet recorded. A repository link, release identifier, DOI and open licence must reflect actual publication decisions and results; none is asserted here.

## Draft for the current partial deposit, after successful publication

Replace the bracketed location with the verified repository URL and commit/release reference before using this paragraph:

> Machine-readable transcriptions of the summary values and settings reported in Tables 1–8, together with curation scripts and provenance records, are available at [verified repository URL and commit or release]. These transcriptions contain reported aggregate values and do not constitute the raw observations used to compute the results. Additional waypoint exports from the simulation project are included; their correspondence to the manuscript's training and evaluation splits has not been established. The deposited package does not contain the complete CE-STPM implementation, aligned simulation training and evaluation sequences, per-sample prediction outputs, or the 150 physical-robot trajectory snippets.

This paragraph describes the available evidence. It does not assert that a partial deposit satisfies all journal requirements, invent a restriction on absent files, or replace an author commitment to deposit the remaining study data.

## Journal source

[MDPI Research Data Policies](https://www.mdpi.com/ethics#_bookmark21) call for the minimum dataset supporting the central findings and an accurate availability statement. The [Applied Sciences author instructions](https://www.mdpi.com/journal/applsci/instructions) remain the journal-specific reference. Direct retrieval of the journal page returned HTTP 429 during preparation; the MDPI policy page was used for general data-sharing guidance.

## 中文核对

当前可公开的是稿件表格的机器可读转录、项目坐标导出和整理工具。论文汇总值不能充当原始实验数据，项目PPO控制器也不能充当CE-STPM实现。需要先确定仓库并实际发布，再填入真实链接；若要说明完整复现，还需补齐`REPRODUCIBILITY.md`列出的原始数据、预测输出与模型代码。当前稿件仍保留原声明。
