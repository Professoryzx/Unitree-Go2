# CE-STPM supporting materials

Supporting materials for **Causally Inspired Feature Calibration for Out-of-Distribution State-Transition Prediction in Quadrupedal Locomotion**, prepared for submission to *Applied Sciences*.

Authors: Yiming Xu, Zhuoxun Yang, Songhai Zhu, Haochuan Zhou and Dianhao Zhang, Nantong University.

**Status: a curated, partial deposit prepared locally; the repository destination and public release have not yet been confirmed.** The supplied simulation project contains useful platform tools and waypoint exports. The CE-STPM predictor, its training/evaluation datasets, and per-sample experiment outputs were not found in the supplied archive. This package therefore supports inspection of reported tables and project waypoint exports; it does not reproduce all experiments in the manuscript.

[中文说明](README.zh-CN.md) · [Data inventory](docs/DATA_INVENTORY.md) · [Project audit](docs/PROJECT_AUDIT.md) · [Availability statement](docs/DATA_AVAILABILITY.md) · [Rights status](LICENSE_STATUS.md)

## Contents

| Location | Contents | Evidence scope |
| --- | --- | --- |
| `data/manuscript_tables/` | Eight manuscript tables, CSV/JSON transcription, 171 numerical result entries, and a Word cross-check | Reported summary values and settings; not raw observations |
| `data/project_waypoints/` | 87 original text exports, normalized CSV, file/sequence manifests and provenance | Project coordinate exports; their correspondence to paper splits or model predictions is unverified |
| `configs/` | Machine-readable records of settings reported in the paper and original project README | Documentation; not a tested training configuration |
| `scripts/` | Table extraction, waypoint conversion/validation, arithmetic checks and checksum verification | Newly written curation tools; no model training implementation |
| `docs/` | Acquisition/data requirements, provenance audit and release notes | Scope and remaining evidence needed |
| `checksums.sha256` | File integrity manifest | Detects changes in the deposit |

The original ZIP, simulator source tree, controller weights, USD scenes, Pickle files and full manuscript remain in the author's local files. They are not redistributed here. Upstream projects and their individual licences are documented in the project audit; no umbrella licence has been assigned to the supplied project or data.

## Inspect and verify

The curation tools use the Python standard library only. Use Python 3.9 or later; Isaac Sim, ROS2, CUDA and model checkpoints are not needed to inspect this deposit.

Run these commands from this directory:

```bash
python3 scripts/verify_checksums.py
python3 scripts/check_waypoints.py
python3 scripts/check_reported_results.py
```

The last command recomputes relative differences using rounded manuscript summary values. It does not evaluate a robot model, recompute sample standard deviations, recover confidence intervals, or validate empirical results against raw data.

For conversion/extraction commands, see the README in each data directory and each tool's `--help`. Table regeneration requires the author's manuscript `.tex` and, for the independent cross-check, the corresponding `.docx`; those full manuscripts are not included in this deposit.

## Related platform

The supplied archive identifies the author's project snapshot with Git commit `36e23601500ed36abd48532adcd869c85b3019b3`. Its README credits [isaac-go2-ros2](https://github.com/Zhefan-Xu/isaac-go2-ros2) and [go2_omniverse](https://github.com/abizovnuralem/go2_omniverse), and its submodule configuration refers to [nav-suite](https://github.com/leggedrobotics/nav-suite). Those links establish dependencies and provenance; they do not establish that the paper's predictor is included or that all supplied files have a redistribution licence.

## Citation and availability

`CITATION.cff` records the manuscript title and authors; no article DOI, dataset DOI or published release is claimed. Consult `docs/DATA_AVAILABILITY.md` before referring to this deposit in the manuscript. The existing manuscript statement has not been edited.
