#!/usr/bin/env python3
"""Verify the curated deposit without external dependencies."""
import argparse
import hashlib
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    root = args.root.resolve()
    manifest = root / 'checksums.sha256'
    failures = []
    names = set()
    for line in manifest.read_text(encoding='utf-8').splitlines():
        expected, relative = line.split('  ', 1)
        path = (root / relative).resolve()
        if root not in path.parents or relative in names:
            failures.append('Invalid manifest path: ' + relative)
            continue
        names.add(relative)
        if not path.is_file():
            failures.append('Missing: ' + relative)
        elif hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            failures.append('Changed: ' + relative)
    actual = {
        p.relative_to(root).as_posix() for p in root.rglob('*')
        if p.is_file() and '.git' not in p.relative_to(root).parts
        and '__pycache__' not in p.parts and p.name != '.DS_Store'
        and p.name != 'checksums.sha256'
    }
    failures.extend('Unlisted: ' + p for p in sorted(actual - names))
    if failures:
        parser.exit(1, '\n'.join(failures) + '\n')
    print('Verified {} files against checksums.sha256'.format(len(names)))


if __name__ == '__main__':
    main()
