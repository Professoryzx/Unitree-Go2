#!/usr/bin/env python3
"""Preserve and convert project waypoint TXT files without simulation dependencies."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import re
from collections import Counter
from pathlib import Path


FORMAT_HEADER = "# Format: COLOR rel_x rel_y rel_z color_r color_g color_b"
BASE_PREFIX = "# Base reference (world):"
POINT_FIELDS = [
    "sequence_id", "point_index", "source_relative_path", "source_line_number",
    "color_label", "rel_x", "rel_y", "rel_z", "color_r", "color_g", "color_b",
]
FILE_FIELDS = [
    "source_relative_path", "raw_relative_path", "source_sha256", "byte_count",
    "line_count", "nonempty_line_count", "file_kind", "data_row_count",
    "source_directory_group", "source_directory", "base_reference_x",
    "base_reference_y", "base_reference_z", "duplicate_content_file_count",
]
SEQUENCE_FIELDS = [
    "sequence_id", "source_relative_path", "normalized_csv_relative_path",
    "source_sha256", "normalized_csv_sha256", "point_count", "color_labels",
    "source_directory_group", "source_directory", "base_reference_x",
    "base_reference_y", "base_reference_z",
]
ENV_FIELDS = ["source_relative_path", "source_sha256", "env_name", "position_text"]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def csv_bytes(fields: list[str], rows: list[dict]) -> bytes:
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return stream.getvalue().encode("utf-8")


def json_bytes(value: dict) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def number_tokens(tokens: list[str], location: str) -> list[str]:
    for token in tokens:
        try:
            value = float(token)
        except ValueError as exc:
            raise ValueError(f"{location}: invalid numeric token {token!r}") from exc
        if not math.isfinite(value):
            raise ValueError(f"{location}: non-finite number")
    # Keep source decimal spellings rather than introducing float rounding.
    return tokens


def parse_file(relative_path: str, data: bytes) -> dict:
    text = data.decode("utf-8")
    lines = text.splitlines()
    path = Path(relative_path)
    result = {
        "source_relative_path": relative_path,
        "raw_relative_path": f"raw/{relative_path}",
        "source_sha256": sha256(data),
        "byte_count": len(data),
        "line_count": len(lines),
        "nonempty_line_count": sum(bool(line.strip()) for line in lines),
        "source_directory_group": path.parts[0] if len(path.parts) > 1 else "",
        "source_directory": path.parent.as_posix() if path.parent != Path(".") else "",
        "base_reference_x": "", "base_reference_y": "", "base_reference_z": "",
        "data_row_count": 0,
    }
    if path.name == "env.txt":
        result["file_kind"] = "environment_note"
        env_name = ""
        position_text = ""
        for line_number, line in enumerate(lines, 1):
            stripped = line.strip()
            if not stripped:
                continue
            match = re.fullmatch(r"env_name:\s*'([^']+)'", stripped)
            if match and not env_name:
                env_name = match.group(1)
            elif re.fullmatch(r"pos=\([^\n]+\),", stripped) and not position_text:
                position_text = stripped
            else:
                raise ValueError(f"{relative_path}:{line_number}: unrecognized environment note")
        if not env_name:
            raise ValueError(f"{relative_path}: environment note has no env_name")
        result["environment_note"] = {
            "source_relative_path": relative_path,
            "source_sha256": result["source_sha256"],
            "env_name": env_name,
            "position_text": position_text,
        }
        result["points"] = []
        return result

    if not lines or lines[0] != FORMAT_HEADER:
        raise ValueError(f"{relative_path}: unsupported waypoint format; no rows discarded")
    result["file_kind"] = "waypoint_format"
    sequence_id = "wp_" + sha256(relative_path.encode("utf-8"))[:16]
    points = []
    base = None
    for line_number, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped or stripped == FORMAT_HEADER:
            continue
        if stripped.startswith(BASE_PREFIX):
            if base is not None:
                raise ValueError(f"{relative_path}:{line_number}: duplicate base reference")
            tokens = stripped[len(BASE_PREFIX):].split()
            if len(tokens) != 3:
                raise ValueError(f"{relative_path}:{line_number}: invalid base reference")
            base = number_tokens(tokens, f"{relative_path}:{line_number}")
            continue
        if stripped.startswith("#"):
            raise ValueError(f"{relative_path}:{line_number}: unsupported header")
        tokens = stripped.split()
        if len(tokens) != 7:
            raise ValueError(f"{relative_path}:{line_number}: expected label and six numeric fields")
        numbers = number_tokens(tokens[1:], f"{relative_path}:{line_number}")
        if any(not 0.0 <= float(value) <= 1.0 for value in numbers[3:]):
            raise ValueError(f"{relative_path}:{line_number}: RGB outside [0, 1]")
        row = {
            "sequence_id": sequence_id, "point_index": len(points) + 1,
            "source_relative_path": relative_path, "source_line_number": line_number,
            "color_label": tokens[0],
        }
        row.update(dict(zip(POINT_FIELDS[5:], numbers)))
        points.append(row)
    if base is None or not points:
        raise ValueError(f"{relative_path}: missing base reference or coordinate rows")
    result.update(dict(zip(["base_reference_x", "base_reference_y", "base_reference_z"], base)))
    result["data_row_count"] = len(points)
    result["points"] = points
    result["sequence_id"] = sequence_id
    return result


def build_products(raw_data: dict[str, bytes]) -> tuple[dict[str, bytes], dict]:
    parsed = [parse_file(name, raw_data[name]) for name in sorted(raw_data)]
    hash_counts = Counter(item["source_sha256"] for item in parsed)
    products = {}
    files, sequences, points, notes = [], [], [], []
    ids = set()
    for item in parsed:
        item["duplicate_content_file_count"] = hash_counts[item["source_sha256"]]
        files.append({field: item[field] for field in FILE_FIELDS})
        if item["file_kind"] == "environment_note":
            notes.append(item["environment_note"])
            continue
        if item["sequence_id"] in ids:
            raise ValueError("Sequence identifier collision")
        ids.add(item["sequence_id"])
        normalized_path = "normalized/" + Path(item["source_relative_path"]).with_suffix(".csv").as_posix()
        normalized_data = csv_bytes(POINT_FIELDS, item["points"])
        products[normalized_path] = normalized_data
        row = {field: item[field] for field in SEQUENCE_FIELDS if field in item}
        row.update({
            "normalized_csv_relative_path": normalized_path,
            "normalized_csv_sha256": sha256(normalized_data),
            "point_count": len(item["points"]),
            "color_labels": json.dumps(sorted({p["color_label"] for p in item["points"]}), ensure_ascii=False),
        })
        sequences.append(row)
        points.extend(item["points"])
    products["files_manifest.csv"] = csv_bytes(FILE_FIELDS, files)
    products["sequences_manifest.csv"] = csv_bytes(SEQUENCE_FIELDS, sequences)
    products["waypoints.csv"] = csv_bytes(POINT_FIELDS, points)
    products["environment_notes.csv"] = csv_bytes(ENV_FIELDS, notes)
    summary = {
        "schema_version": 1,
        "source_txt_file_count": len(parsed),
        "source_byte_count": sum(item["byte_count"] for item in parsed),
        "source_line_count": sum(item["line_count"] for item in parsed),
        "waypoint_format_file_count": len(sequences),
        "environment_note_file_count": len(notes),
        "coordinate_record_count": len(points),
        "color_label_record_counts": dict(sorted(Counter(p["color_label"] for p in points).items())),
        "source_directory_group_file_counts": dict(sorted(Counter(item["source_directory_group"] for item in parsed).items())),
        "unique_source_content_sha256_count": len(hash_counts),
        "duplicate_content_groups": sum(count > 1 for count in hash_counts.values()),
        "waypoint_format_unique_content_sha256_count": len({s["source_sha256"] for s in sequences}),
        "source_classification": "original directory names only; not mapped to paper experiments",
        "paper_150_real_robot_trajectory_mapping": "not established",
        "paper_table_result_mapping": "not established",
        "per_point_timestamps": "not provided",
        "coordinate_units": "not specified in TXT files; not independently established",
        "coordinate_frame": "relative to encoded Base reference (world); physical frame and axes not independently established",
    }
    products["summary.json"] = json_bytes(summary)
    return products, summary


def read_source(source: Path) -> dict[str, bytes]:
    if not source.is_dir():
        raise ValueError(f"Missing source directory: {source}")
    raw_data = {}
    for path in sorted(source.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"Symlink not supported: {path}")
        if not path.is_file():
            continue
        if path.suffix != ".txt":
            raise ValueError(f"Unexpected non-TXT source file: {path}")
        raw_data[path.relative_to(source).as_posix()] = path.read_bytes()
    if not raw_data:
        raise ValueError("No source TXT files")
    return raw_data


def write_product(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_bytes() == data:
        return
    path.write_bytes(data)


def convert(source: Path, output: Path) -> dict:
    if source.resolve() == output.resolve() or source.resolve() in output.resolve().parents:
        raise ValueError("Output must not be inside the source directory")
    raw_data = read_source(source)
    products, summary = build_products(raw_data)
    for relative_path, data in raw_data.items():
        write_product(output / "raw" / relative_path, data)
    for relative_path, data in products.items():
        write_product(output / relative_path, data)
    return summary


def check(output: Path, source: Path | None = None) -> dict:
    raw_data = read_source(output / "raw")
    products, summary = build_products(raw_data)
    for relative_path, expected in products.items():
        target = output / relative_path
        if not target.is_file() or target.read_bytes() != expected:
            raise ValueError(f"Missing or changed derived file: {relative_path}")
    expected_csv = {path for path in products if path.startswith("normalized/")}
    observed_csv = {
        path.relative_to(output).as_posix()
        for path in (output / "normalized").rglob("*") if path.is_file()
    }
    if observed_csv != expected_csv:
        raise ValueError("Unexpected or missing normalized files")
    original_checked = False
    if source is not None:
        original = read_source(source)
        if original != raw_data:
            raise ValueError("Raw copies differ from original source paths or bytes")
        original_checked = True
    return {
        "status": "passed", "raw_files_checked": len(raw_data),
        "derived_files_checked": len(products),
        "coordinate_records_checked": summary["coordinate_record_count"],
        "original_source_byte_comparison": original_checked,
        "checks": [
            "UTF-8 and exact expected TXT format", "finite coordinate and RGB values",
            "RGB range", "base reference and source row mapping",
            "raw SHA256, bytes, physical lines and directory labels",
            "all derived CSV and JSON content regenerated from raw bytes",
            "no missing or extra normalized files", "duplicate contents retained",
        ],
        "paper_experiment_correspondence_checked": False,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True, help="Original waypoints_data directory")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parents[1] / "data/project_waypoints")
    args = parser.parse_args()
    result = convert(args.source, args.output)
    verification = check(args.output, args.source)
    print(json.dumps({"summary": result, "verification": verification}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
