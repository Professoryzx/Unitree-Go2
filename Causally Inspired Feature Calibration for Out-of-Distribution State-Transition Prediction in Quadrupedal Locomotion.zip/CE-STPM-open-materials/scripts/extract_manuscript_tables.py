#!/usr/bin/env python3
"""Transcribe this manuscript's eight tables and check against its Word version.

Standard library only. This is a transcription utility, not an experiment or
statistical analysis. The manuscript itself is deliberately not redistributed.
"""
import argparse
import csv
import hashlib
import json
import re
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path


LABELS = ["notation", "configuration", "protocol", "displacement", "risk",
          "association", "friction", "real"]
HEADERS = {
    "notation": ["symbol_latex", "meaning"],
    "configuration": ["setting", "value"],
    "protocol": ["partition", "flat_percent", "stairs_percent", "slopes_percent",
                 "obstacles_percent", "rough_percent", "positive_labels_percent",
                 "friction_mix_percent_mu_ge_0.6_to_mu_lt_0.6",
                 "contact_mix_percent_rigid_to_compliant"],
    "displacement": ["method", "FDE_ID_m_mean_plus_minus_sample_sd",
                     "FDE_OOD-G_m_mean_plus_minus_sample_sd",
                     "FDE_OOD-P_m_mean_plus_minus_sample_sd",
                     "ADE_ID_m_mean_plus_minus_sample_sd",
                     "ADE_OOD-G_m_mean_plus_minus_sample_sd",
                     "ADE_OOD-P_m_mean_plus_minus_sample_sd"],
    "risk": ["method", "ID_precision", "ID_recall", "ID_F1", "OOD-G_precision",
             "OOD-G_recall", "OOD-G_F1", "OOD-P_precision", "OOD-P_recall", "OOD-P_F1"],
    "association": ["method", "association_preserved_FDE_m",
                    "association_broken_FDE_m", "relative_FDE_increase_percent"],
    "friction": ["friction_coefficient_mu", "STPM-Base_FDE_m", "STPM+DR_FDE_m",
                 "D-FAM only_FDE_m", "CE-STPM_FDE_m"],
    "real": ["scene", "method", "ADE_m", "FDE_m", "risk_precision_percent"],
}
SCENES = {"1": "indoor corridor", "2": "outdoor mixed terrain", "3": "wild unstructured terrain"}
WS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"


def braces(text, start):
    """Read balanced braces and return their content and the next offset."""
    if text[start] != "{":
        raise ValueError("Expected a brace")
    level = 1
    i = start + 1
    while i < len(text):
        if text[i] == "{" and (i == 0 or text[i - 1] != "\\"):
            level += 1
        elif text[i] == "}" and text[i - 1] != "\\":
            level -= 1
            if level == 0:
                return text[start + 1:i], i + 1
        i += 1
    raise ValueError("Unbalanced braces")


def get_command_arg(text, command):
    match = re.search(r"\\" + command + r"\s*\{", text)
    return braces(text, match.end() - 1)[0] if match else ""


def split_top(text, token):
    """Split delimiters outside braces; ignore shortstack's internal line breaks."""
    result, start, level, i = [], 0, 0, 0
    while i < len(text):
        if text[i] == "{" and (i == 0 or text[i - 1] != "\\"):
            level += 1
        elif text[i] == "}" and (i == 0 or text[i - 1] != "\\"):
            level -= 1
        if level == 0 and text.startswith(token, i):
            result.append(text[start:i].strip())
            i += len(token)
            start = i
        else:
            i += 1
    if text[start:].strip():
        result.append(text[start:].strip())
    return result


def plain(cell):
    """Remove display-only LaTeX, preserving published digits and +/- signs."""
    cell = re.sub(r"\\cite\{[^}]*\}", "", cell)
    cell = re.sub(r"\\(?:textbf|mathbf|mathrm|textnormal|textit|mathcal)\s*", "", cell)
    mappings = {r"\pm": "±", r"\times": "×", r"\mu": "μ", r"\geq": "≥",
                r"\lambda": "λ", r"\delta": "δ", r"\ell": "ℓ", r"\pi": "π",
                r"\alpha": "α", r"\beta": "β", r"\Omega": "Ω", r"\prime": "′",
                r"\%": "%", r"\!": "", r"\,": " ", r"\(": "", r"\)": "",
                r"\ ": " ", "~": " ", "$": ""}
    for old, new in mappings.items():
        cell = cell.replace(old, new)
    cell = cell.replace("{", "").replace("}", "")
    return re.sub(r"\s+", " ", cell).strip()


def read_latex(path):
    source = path.read_text(encoding="utf-8")
    blocks = re.findall(r"\\begin\{table\}.*?\\end\{table\}", source, re.S)
    if len(blocks) != 8:
        raise ValueError(f"Expected eight manuscript tables, found {len(blocks)}")
    tables = []
    for number, block in enumerate(blocks, 1):
        label = get_command_arg(block, "label").removeprefix("tab:")
        if label != LABELS[number - 1]:
            raise ValueError(f"Unexpected table {number}: {label}")
        # Comments are source annotations, not instructions.
        source_annotations = [line.strip()[1:].strip() for line in block.splitlines()
                              if line.strip().startswith("%")]
        block_no_comments = re.sub(r"(?m)^\s*%.*$", "", block)
        body = block_no_comments.split(r"\toprule", 1)[1].split(r"\bottomrule", 1)[0]
        rows = []
        for line in split_top(body, r"\\"):
            line = re.sub(r"^\s*\[[^]]*\]", "", line)
            line = re.sub(r"\\(?:toprule|midrule|addlinespace)", "", line)
            line = re.sub(r"\\cmidrule(?:\([^)]*\))?\{[^}]*\}", "", line).strip()
            if line:
                rows.append(split_top(line, "&"))
        start = 2 if label in ("displacement", "risk", "protocol") else 1
        raw_data = rows[start:]
        # Table 2's merged section-heading rows are metadata, not measurements.
        sections, current_section, data, latex_cells = [], "", [], []
        for row in raw_data:
            if label == "configuration" and len(row) == 1:
                section_text = get_command_arg(row[0], "multicolumn")
                match = re.search(r"\\textit\{([^}]*)\}", row[0])
                current_section = match.group(1) if match else section_text
                continue
            cleaned = [plain(c) for c in row]
            if label == "notation":
                cleaned[0] = row[0]
            if label == "real" and not cleaned[0]:
                cleaned[0] = data[-1][0]
            if len(cleaned) != len(HEADERS[label]):
                raise ValueError(f"Invalid row width in table {number}: {cleaned}")
            data.append(cleaned)
            latex_cells.append(row)
            sections.append(current_section)
        tables.append({"table_number": number, "label": "tab:" + label,
                       "caption": plain(get_command_arg(block, "caption")),
                       "caption_latex": get_command_arg(block, "caption"),
                       "columns": HEADERS[label], "rows": data,
                       "source_cells_latex": latex_cells, "row_sections": sections,
                       "source_annotations": source_annotations,
                       "headers_latex": rows[:start]})
    return tables


def word_tables(path):
    with zipfile.ZipFile(path) as archive:
        document = ET.fromstring(archive.read("word/document.xml"))
    result = []
    for index, table in enumerate(document.findall(f".//{{{WS}}}tbl"), 1):
        rows = [["".join(node.text or "" for node in cell.iter() if node.tag.endswith("}t"))
                 for cell in row.findall(f"{{{WS}}}tc")]
                for row in table.findall(f"{{{WS}}}tr")]
        # Word also uses tables for equation layout. Content tables have >=4 rows.
        if len(rows) >= 4:
            result.append({"word_xml_table_index": index, "rows": rows})
    if len(result) != 8:
        raise ValueError(f"Expected eight Word content tables, found {len(result)}")
    return result


def canonical(text):
    text = unicodedata.normalize("NFKC", text)
    text = re.sub(r"\[[0-9, ]+\]", "", text)
    text = text.replace("−", "-").replace("_", "").replace("^", "")
    return "".join(c for c in text if not c.isspace() and c not in "\u200b\u200c\u200d").replace("--", "-")


def validate(tables, docx_path):
    words = word_tables(docx_path)
    reports = []
    errors = []
    for table, word in zip(tables, words):
        label = table["label"].removeprefix("tab:")
        word_data = word["rows"][1:]
        if label == "configuration":
            word_data = [row for row in word_data if len(row) == 2]
        if len(word_data) != len(table["rows"]):
            raise ValueError(f"Row count differs for {label}")
        checked = 0
        exclusions = []
        for r, (latex_row, word_row) in enumerate(zip(table["rows"], word_data), 1):
            for c, (value, word_value) in enumerate(zip(latex_row, word_row), 1):
                if label == "notation" and c == 1:
                    exclusions.append({"row": r, "column": c,
                                       "reason": "OMML notation accents/subscripts are not compared as plain text; exact LaTeX retained."})
                    continue
                if label == "configuration" and value.startswith("Simulator root position"):
                    # The Word version reorders the inline coordinate expression.
                    expected = "Simulator root position, in the world frame (x,y,z)"
                    if canonical(word_value) != canonical(expected):
                        errors.append({"table": label, "row": r, "column": c,
                                       "latex": value, "word": word_value})
                    checked += 1
                    continue
                if canonical(value) != canonical(word_value):
                    errors.append({"table": label, "row": r, "column": c,
                                   "latex": value, "word": word_value})
                checked += 1
        reports.append({"table_number": table["table_number"], "label": table["label"],
                        "word_xml_table_index": word["word_xml_table_index"],
                        "data_rows": len(word_data), "checked_cells": checked,
                        "excluded_cells": exclusions})
    report = {"status": "passed" if not errors else "failed",
              "scope": "Independent cell text from word/document.xml; checks data cells, not equation-layout tables or table headers.",
              "checked_cells": sum(t["checked_cells"] for t in reports),
              "tables": reports, "mismatches": errors}
    if errors:
        raise ValueError(json.dumps(report, ensure_ascii=False, indent=2))
    return report


def long_rows(tables):
    records = []
    def add(number, method, regime, metric, unit, value, **extra):
        mean, sd = (value.split("±") + [""])[:2] if "±" in value else (value, "")
        records.append({"table_number": number, "method": method, "regime": regime,
                        "metric": metric, "unit": unit, "reported_value": value,
                        "mean_or_value": mean, "sample_sd": sd,
                        "provenance": "manuscript_table_transcription", **extra})
    for table in tables:
        number, label = table["table_number"], table["label"].removeprefix("tab:")
        if label == "displacement":
            for row in table["rows"]:
                for i, value in enumerate(row[1:]):
                    add(number, row[0], ["ID", "OOD-G", "OOD-P"][i % 3],
                        "FDE" if i < 3 else "ADE", "m", value,
                        sample_count_description="at least 500 prediction samples per method and regime")
        elif label == "risk":
            for row in table["rows"]:
                for i, value in enumerate(row[1:]):
                    add(number, row[0], ["ID", "OOD-G", "OOD-P"][i // 3],
                        ["precision", "recall", "F1"][i % 3], "fraction", value)
        elif label == "association":
            for row in table["rows"]:
                add(number, row[0], "association preserved", "FDE", "m", row[1])
                add(number, row[0], "association broken", "FDE", "m", row[2])
                add(number, row[0], "broken relative to preserved", "relative FDE increase", "%", row[3])
        elif label == "friction":
            methods = ["STPM-Base", "STPM+DR", "D-FAM only", "CE-STPM"]
            for row in table["rows"]:
                for method, value in zip(methods, row[1:]):
                    add(number, method, "friction sweep", "FDE", "m", value,
                        friction_coefficient_mu=row[0], geometry="generation procedure held fixed")
        elif label == "real":
            for row in table["rows"]:
                for metric, unit, value in zip(["ADE", "FDE", "risk precision"], ["m", "m", "%"], row[2:]):
                    add(number, row[1], SCENES[row[0]], metric, unit, value,
                        scene_id=row[0], sample_count_description="50 snippets per scene group",
                        deployment_condition="offline terrain priors")
    return records


def write_csv(path, columns, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(columns)
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--latex", required=True, type=Path, help="Local manuscript .tex; not copied to outputs")
    parser.add_argument("--word", required=True, type=Path, help="Matching local .docx; read only")
    parser.add_argument("--output", required=True, type=Path, help="Output directory for table transcriptions")
    args = parser.parse_args()
    tables = read_latex(args.latex)
    validation = validate(tables, args.word)
    args.output.mkdir(parents=True, exist_ok=True)
    for table in tables:
        label = table["label"].removeprefix("tab:")
        filename = f"table_{table['table_number']:02d}_{label}.csv"
        write_csv(args.output / filename, table["columns"], table["rows"])
        table["csv_file"] = filename
    records = long_rows(tables)
    columns = ["table_number", "method", "regime", "metric", "unit", "reported_value",
               "mean_or_value", "sample_sd", "friction_coefficient_mu", "scene_id",
               "sample_count_description", "geometry", "deployment_condition", "provenance"]
    write_csv(args.output / "results_long.csv", columns, [[r.get(c, "") for c in columns] for r in records])
    provenance = {"data_type": "manuscript summary table transcription; not raw experimental data",
                  "independent_recomputation": False,
                  "sources": [{"filename": p.name, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
                              for p in (args.latex, args.word)],
                  "no_manuscript_copy": True,
                  "notes": ["LaTeX values preserve the published textual precision.",
                            "Word cross-check is a consistency check between manuscript formats, not experimental validation.",
                            "Original LaTeX source annotations mention AAA.pdf; that prior source was not independently checked by this utility.",
                            "FDE/ADE ± values are reported sample standard deviations, not standard errors or confidence intervals."]}
    payload = {"provenance": provenance, "tables": tables, "results_long": records,
               "protocol_notes": {"low_friction": "dimensionless coefficient μ < 0.6",
                                  "compliant_contact_stiffness": "10^4–10^5 N/m",
                                  "compliant_contact_damping": "10^2–10^4 N s/m",
                                  "risk_metric_scale_table_5": "fractions, not percentages",
                                  "risk_precision_scale_table_8": "percentages"}}
    (args.output / "manuscript_tables.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (args.output / "word_validation.json").write_text(json.dumps(validation, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote 8 tables and {len(records)} long-format result records; Word cross-check: {validation['checked_cells']} cells passed.")


if __name__ == "__main__":
    main()
