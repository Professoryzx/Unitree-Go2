#!/usr/bin/env python3
"""Verify raw waypoint files and every derived CSV without importing simulation code."""

import argparse
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from convert_waypoints import check


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=Path(__file__).resolve().parents[1] / "data/project_waypoints")
    parser.add_argument("--source", type=Path, help="Optional original source for direct byte comparison")
    parser.add_argument("--report", type=Path, help="Optional JSON report output")
    args = parser.parse_args()
    try:
        report = check(args.data, args.source)
    except (ValueError, OSError, UnicodeError) as exc:
        print(json.dumps({"status": "failed", "error": str(exc)}, ensure_ascii=False, indent=2))
        raise SystemExit(1)
    encoded = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(encoded, encoding="utf-8")
    print(encoded, end="")


if __name__ == "__main__":
    main()
