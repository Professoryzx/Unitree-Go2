#!/usr/bin/env python3
"""Recompute manuscript comparisons from transcribed aggregate values only."""
import argparse
import csv
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path


def rounded(value):
    return str(value.quantize(Decimal('0.1'), rounding=ROUND_HALF_UP))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--csv', type=Path, default=Path(__file__).resolve().parents[1] /
                        'data/manuscript_tables/results_long.csv')
    args = parser.parse_args()
    with args.csv.open(encoding='utf-8', newline='') as stream:
        rows = list(csv.DictReader(stream))

    def select(table, metric, regime, method):
        matched = [r for r in rows if r['table_number'] == str(table)
                   and r['metric'] == metric and r['regime'] == regime and r['method'] == method]
        if len(matched) != 1:
            raise ValueError('Expected exactly one aggregate for ' + repr((table, metric, regime, method)))
        return Decimal(matched[0]['mean_or_value'])

    expected_fde = {'ID': '15.6', 'OOD-G': '44.3', 'OOD-P': '47.9'}
    expected_f1 = {'ID': '5.0', 'OOD-G': '5.0', 'OOD-P': '11.0'}
    for regime in ['ID', 'OOD-G', 'OOD-P']:
        base = select(4, 'FDE', regime, 'STPM-Base')
        full = select(4, 'FDE', regime, 'CE-STPM')
        fde_change = Decimal(100) * (base - full) / base
        gain = Decimal(100) * (select(5, 'F1', regime, 'CE-STPM') -
                              select(5, 'F1', regime, 'STPM-Base'))
        if rounded(fde_change) != expected_fde[regime] or rounded(gain) != expected_f1[regime]:
            raise ValueError('Reported comparison changed: ' + regime)
        print('{}: FDE reduction {}%; F1 gain {} percentage points versus STPM-Base'.format(
              regime, rounded(fde_change), rounded(gain)))
    print('Checked rounded aggregate arithmetic only; raw experiment results were not evaluated.')


if __name__ == '__main__':
    main()
