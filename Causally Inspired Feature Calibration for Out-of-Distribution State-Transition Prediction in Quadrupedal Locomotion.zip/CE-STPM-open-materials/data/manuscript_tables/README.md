# Manuscript table transcriptions

These files transcribe the eight tables in **Causally Inspired Feature Calibration for Out-of-Distribution State-Transition Prediction in Quadrupedal Locomotion**. They provide the reported settings, split descriptions, and aggregate results in machine-readable form.

**They are manuscript summary tables, not raw experimental data, per-sample model outputs, training records, or an independent reproduction of the experiments.** No new measurements or statistical tests were performed to generate these files. The complete manuscript is not included in this directory or copied by the extraction script.

## Files and coverage

| Manuscript table | File | Contents |
| --- | --- | --- |
| 1 | `table_01_notation.csv` | Exact LaTeX notation and its stated meaning; 18 rows |
| 2 | `table_02_configuration.csv` | Hardware, raw simulation acquisition intervals, model and training settings; 28 rows |
| 3 | `table_03_protocol.csv` | Training, validation, ID, OOD-G, and OOD-P terrain/contact distributions; 5 rows |
| 4 | `table_04_displacement.csv` | FDE and ADE, reported mean ± sample standard deviation, for 8 methods and 3 regimes |
| 5 | `table_05_risk.csv` | Reported risk precision, recall, and F1 for 7 learned methods and 3 regimes |
| 6 | `table_06_association.csv` | FDE with terrain/physics associations preserved or broken and reported rounded percentage increases; 4 methods |
| 7 | `table_07_friction.csv` | FDE at friction coefficients 0.8, 0.6, and 0.4 for 4 methods |
| 8 | `table_08_real.csv` | ADE, FDE, and risk precision for 4 methods in 3 Go2 deployment scene groups |
| 4–8 | `results_long.csv` | 171 long-format aggregate result records, with explicit method, regime, metric, and unit |
| 1–8 | `manuscript_tables.json` | All tables, captions, exact source LaTeX cells, source annotations, table-section metadata, protocol notes, long-format records, and source-file SHA-256 hashes |
| 1–8 | `word_validation.json` | Independent cross-format comparison against cell text read from `word/document.xml` |

## Provenance and verification

The primary transcription source is the locally supplied LaTeX manuscript. Each table's original LaTeX cells are retained in JSON so that display formatting, bold markings, citation keys, notation, and numerical precision remain inspectable. CSV method names omit inline citations; the exact cited source cell remains in JSON. The source filenames and SHA-256 hashes are recorded in `manuscript_tables.json` without publishing local filesystem paths or copying the manuscript.

The matching Word document was independently read as a ZIP archive; it was not modified. Word contains 27 XML tables, of which 19 are equation-layout tables. The eight content tables occur at XML table indices 3 and 21–27. The extraction checks 336 data cells against the Word version and reports zero mismatches. This checks transcription consistency between two manuscript formats; it does not validate the underlying experiments. It does not compare table headers or reconstruct full equation/notation semantics from Word OMML. The 18 symbolic cells in Table 1 therefore retain exact LaTeX without a plain-text equivalence claim. Their meaning cells are cross-checked. The Table 2 position-source wording is semantically equivalent but moves `(x,y,z)` to the end in Word; the tool explicitly checks that known wording variant.

Some LaTeX source comments identify earlier tables in `AAA.pdf`. Those comments are retained as source annotations. This extraction did not independently check that earlier PDF or its underlying experimental records.

## Units, statistics, and interpretation

- FDE and ADE are in meters. Table 4 uses the reported **mean ± sample standard deviation**. The standard deviations are not standard errors or confidence intervals. The manuscript reports at least 500 prediction samples per method and simulation regime; exact sample counts and individual errors are not provided by these tables.
- Table 5 precision, recall, and F1 are **fractions** (for example `0.90`), while Table 8 risk precision is a **percentage** (for example `88`). The files deliberately preserve that difference. F1 is retained exactly as reported; it is not recomputed from the rounded precision and recall columns.
- Table 3 terrain proportions and positive-label fractions are percentages. Its friction and contact mixture strings preserve the reported percentage pairs, such as `80 : 20`. Friction order is `μ ≥ 0.6 : μ < 0.6`; contact order is `rigid : compliant`. The friction coefficient itself is dimensionless. The reported compliant-contact ranges are stiffness `10^4–10^5 N/m` and damping `10^2–10^4 N s/m`, retained in JSON metadata.
- Table 6 stores the reported signs and whole-number percentages (`+53`, `+52`, `+30`, `+29`). These are relative changes from preserved to broken associations, rather than percentage-point differences.
- Table 7 varies friction under a fixed geometry-generation procedure. Its entries are FDE summaries; it provides no per-sample values or dispersion.
- Table 8 represents **50 trajectory snippets in each of three scene groups**, for 150 snippets altogether: 1 = indoor corridor, 2 = outdoor mixed terrain, 3 = wild unstructured terrain. It concerns a deployment system using offline terrain priors. The table does not provide individual snippets, uncertainty, risk recall, or risk confusion counts.
- Numeric strings retain the source precision, including trailing zeros, `±`, and explicit plus signs. Values should be parsed as numbers only for a stated downstream calculation. `reported_value` preserves the presentation; `mean_or_value` and `sample_sd` separate the two components where present. Blank `sample_sd` means no standard deviation was tabulated, not zero.
- Const-Vel and the named STPM comparators are the implementations evaluated in this study. The manuscript's methodological citations do not make these values results reported by the cited third-party papers.

## What these files can support

These files permit inspection of the reported quantitative comparisons in Tables 4–8, reconstruction of plots drawn from those aggregate values, and arithmetic checks of reported relative FDE/ADE reductions and F1 percentage-point gains. Tables 4 and 5 contain the aggregate inputs for the manuscript's distribution-summary figure (`fig:distribution_summary`). Tables 4 and 8 contain the aggregate inputs for the simulation and field error figure (`fig:controlled_and_field`). Tables 1–3 preserve the reported notation and high-level experimental protocol.

They do not establish the reproducibility of training, sampling, labels, trajectory-level errors, or statistical significance. The selected simulation and field images also cannot be recreated from table entries alone. Field precision alone does not quantify missed risks or establish closed-loop navigation safety.

## Experimental evidence still needed for reproduction

To independently reproduce the manuscript's experimental results, the release would additionally need the relevant materials below, or a documented access route for each unavailable item:

1. Simulation sequences with synchronized timestamps, observations/proprioception, local terrain/elevation scans, candidate command sequences, world-frame reference positions, and binary risk labels, together with coordinate-frame and label definitions.
2. Sample/trajectory identifiers and explicit training, validation, ID, OOD-G, and OOD-P membership; exact evaluation sample counts; preprocessing and window-generation rules; collection seeds; terrain-generation and physics configurations. Association-preserved/broken and friction-sweep runs need their own manifests and settings.
3. Per-sample prediction sequences and risk scores for every reported method, the fixed classification-threshold selection procedure and selected threshold, and metric computation code. These are needed to recompute means, sample standard deviations, precision, recall, F1, and confusion counts independently.
4. The trained CE-STPM and comparator implementations, checkpoints, training logs, terrain prototypes/prior frequencies, global dynamics dictionary, and the software/dependency versions used for the reported runs.
5. The 150 physical-robot snippets and their scene identifiers, synchronized sensor/state/command records, offline terrain priors, FAST-LIO reference-position records, risk annotations and their provenance, and frame/calibration metadata. Any privacy or redistribution limits should be documented for the actual affected files.
6. Selected qualitative trajectory overlays and the source records underlying the simulation/deployment figures, if those figures are to be reproduced.

This is an evidence inventory, not a claim that these materials are present elsewhere in this repository. The source project alone should not be treated as the manuscript's experimental dataset.

## Repeat the transcription

The standard-library utility accepts the author's existing manuscript files as local inputs and writes table outputs to an explicit destination:

```sh
python3 scripts/extract_manuscript_tables.py \
  --latex /path/to/manuscript.tex \
  --word /path/to/manuscript.docx \
  --output data/manuscript_tables
```

The utility stops if the eight expected tables, row widths, or Word consistency checks change. The CSV/JSON outputs are deterministic for identical input files. This README explains release scope and is maintained separately from the generated outputs.

中文说明：本目录是论文汇总表的忠实转录，336 个数据单元格已从 Word XML 独立核验。它可以核对论文表格、汇总图与改善率，但不能作为原始实验数据或完整复现实验的证据。原始轨迹、逐样本预测、标签、数据划分、实际模型代码和权重仍需另行补齐或说明获取方式。
